#!/usr/bin/env python3
"""
Generiert alle Texturen, Modelle, Item-Definitionen und die Frame-Konstanten.
Aufruf (im Projektordner):  python3 tools/generate.py      (benötigt: pip install pillow)

Die Animationen werden hier als Keyframes beschrieben (siehe PULL / INSPECT / AURA)
und zu jeweils einem Modell pro Tick ausgebacken.  Wenn du Bewegungen anpassen willst,
änderst du nur die Keyframes unten und startest das Skript neu.
"""
import json, math, os, random
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NS = "butterflyknife"
ASSETS = os.path.join(ROOT, "src/main/resources/assets", NS)
JAVA_OUT = os.path.join(ROOT, "src/main/java/dev/butterflyknife/client/AnimationFrames.java")

# ----------------------------------------------------------------------------
# 1. Varianten / Paletten  (Klinge hell/mittel/dunkel, Pivot-Niete)
# ----------------------------------------------------------------------------
HANDLE = dict(base=(36, 36, 40), rib=(64, 64, 70), dark=(20, 20, 24))
HANDLE_NETHERITE = dict(base=(46, 36, 50), rib=(74, 58, 78), dark=(28, 20, 32))

VARIANTS = {
    "wood":      dict(light=(214, 168, 86),  base=(178, 130, 52),  dark=(128, 90, 34),  rivet=(235, 165, 40),  handle=HANDLE, style="wood"),
    "copper":    dict(light=(238, 150, 100), base=(204, 108, 62),  dark=(150, 70, 40),  rivet=(240, 120, 40),  handle=HANDLE, style="bands"),
    "iron":      dict(light=(240, 240, 240), base=(200, 200, 204), dark=(140, 140, 148), rivet=(245, 245, 245), handle=HANDLE, style="bands"),
    "gold":      dict(light=(255, 236, 100), base=(242, 192, 32),  dark=(186, 128, 10),  rivet=(255, 216, 40),  handle=HANDLE, style="bands"),
    "diamond":   dict(light=(150, 248, 238), base=(72, 208, 204),  dark=(34, 138, 150),  rivet=(60, 235, 235),  handle=HANDLE, style="bands"),
    "netherite": dict(light=(112, 86, 108),  base=(78, 56, 72),    dark=(44, 30, 44),    rivet=(60, 170, 160),  handle=HANDLE_NETHERITE, style="bands"),
    "stone":     dict(light=(158, 158, 158), base=(126, 126, 126), dark=(88, 88, 88),    rivet=(176, 176, 176), handle=HANDLE, style="stone"),
}

# ----------------------------------------------------------------------------
# 2. Texturen (64x64, 4 px pro Modell-Einheit)
# ----------------------------------------------------------------------------
def draw_texture(name, v):
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    px = img.load()
    h = v["handle"]
    rng = random.Random(name)

    # Griff-Seitenfläche (0,0)-(28,6): schräge Riffelung + Pivot-Niete rechts
    for y in range(6):
        for x in range(28):
            if y in (0, 5) or x == 27:
                c = h["dark"]
            elif (x + 2 * y) % 6 < 2:
                c = h["rib"]
            else:
                c = h["base"]
            px[x, y] = c + (255,)
    for dx in range(2):
        for dy in range(2):
            px[24 + dx, 2 + dy] = v["rivet"] + (255,)
    px[24, 2] = tuple(min(255, int(c * 1.25) + 15) for c in v["rivet"]) + (255,)

    # Griff-Kante (0,8)-(28,12) und Stirnseite (0,12)-(4,18)
    for y in range(8, 12):
        for x in range(28):
            px[x, y] = (h["rib"] if x % 6 < 2 else h["dark"]) + (255,)
    for y in range(12, 18):
        for x in range(4):
            px[x, y] = h["dark"] + (255,)

    # Klinge (0,20)-(36,36): Silhouette (Clip-Point) per Alpha
    poly = [(0, 2), (26, 2), (35, 9), (31, 12), (26, 14), (0, 14)]
    mask = Image.new("L", (36, 16), 0)
    ImageDraw.Draw(mask).polygon(poly, fill=255)
    m = mask.load()

    def inside(x, y):
        return 0 <= x < 36 and 0 <= y < 16 and m[x, y] > 0

    for y in range(16):
        for x in range(36):
            if not inside(x, y):
                continue
            edge = not (inside(x - 1, y) and inside(x + 1, y) and inside(x, y - 1) and inside(x, y + 1))
            if v["style"] == "stone":
                r = rng.random()
                c = v["light"] if r < 0.18 else v["dark"] if r > 0.80 else v["base"]
            elif v["style"] == "wood":
                streak = (y * 7 + (x // 5) * 3) % 5
                c = v["light"] if streak == 0 else v["dark"] if streak == 3 else v["base"]
            else:
                d = (x + 2 * y) % 12
                c = v["light"] if d < 3 else v["dark"] if d > 9 else v["base"]
            if y == 7 and 8 <= x <= 24:      # Hohlkehle (Fuller)
                c = v["dark"]
            elif y == 8 and 8 <= x <= 24:
                c = v["light"]
            if edge:
                c = v["light"] if (y >= 12 and x > 5) else v["dark"]   # Schneide hell, Rücken dunkel
            px[x, 20 + y] = c + (255,)
    path = os.path.join(ASSETS, "textures/item", f"{name}.png")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)
    return img

# ----------------------------------------------------------------------------
# 3. Modellgeometrie
# ----------------------------------------------------------------------------
def handle_faces():
    tex = "#0"
    return {"south": {"uv": [0, 0, 7, 1.5], "texture": tex},
            "north": {"uv": [7, 0, 0, 1.5], "texture": tex},
            "up": {"uv": [0, 2, 7, 3], "texture": tex},
            "down": {"uv": [0, 2, 7, 3], "texture": tex},
            "east": {"uv": [0, 3, 1, 4.5], "texture": tex},
            "west": {"uv": [0, 3, 1, 4.5], "texture": tex}}

def elements(ha, hb):
    tex = "#0"
    return [
        {   # Klinge (nur Vorder-/Rückseite, die Form kommt aus der Textur-Transparenz)
            "name": "blade", "from": [7, 6, 7.6], "to": [16, 10, 8.4],
            "faces": {"south": {"uv": [0, 5, 9, 9], "texture": tex},
                      "north": {"uv": [9, 5, 0, 9], "texture": tex}}},
        {   # oberer Griff, schwenkt um den Pivot (6.7, 10)
            "name": "handle_a", "from": [0.2, 9.25, 8.4], "to": [7.2, 10.75, 9.4],
            "rotation": {"origin": [6.7, 10, 8.9], "axis": "z", "angle": round(ha, 3)},
            "faces": handle_faces()},
        {   # unterer Griff, schwenkt um den Pivot (6.7, 6)
            "name": "handle_b", "from": [0.2, 5.25, 6.6], "to": [7.2, 6.75, 7.6],
            "rotation": {"origin": [6.7, 6, 7.1], "axis": "z", "angle": round(hb, 3)},
            "faces": handle_faces()},
    ]

BASE = dict(rx=0, ry=-90, rz=25, tx=1.1, ty=3.2, tz=1.1, s=0.8, ha=0, hb=0)

def clamp(v):
    return round(max(-80, min(80, v)), 2)

def fp_display(p):
    return {"rotation": [round(p["rx"], 2), round(p["ry"], 2), round(p["rz"], 2)],
            "translation": [clamp(p["tx"]), clamp(p["ty"]), clamp(p["tz"])],
            "scale": [round(p["s"], 3)] * 3}

STATIC_DISPLAY = {
    "gui": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
    "thirdperson_righthand": {"rotation": [0, -90, 10], "translation": [0, 4, 0.5], "scale": [0.85, 0.85, 0.85]},
    "thirdperson_lefthand": {"rotation": [0, 90, -10], "translation": [0, 4, 0.5], "scale": [0.85, 0.85, 0.85]},
    "firstperson_lefthand": {"rotation": [0, 90, -20], "translation": [1.1, 3.2, 1.1], "scale": [0.8, 0.8, 0.8]},
}

# ----------------------------------------------------------------------------
# 4. Keyframes  (Zeit = Tick/Frame, 20 pro Sekunde).  Fehlende Kanäle = BASE.
#    ha/hb = Schwenkwinkel der Griffe: 0 = offen, -180/+180 = geschlossen,
#    -360/+360 = einmal komplett herum (= wieder offen).
#    rx/ry/rz = Anzeige-Rotation der ganzen Hand-Pose, tx/ty/tz = Verschiebung.
#    HINWEIS: Das ist eine Annäherung an die CS-Bewegungen, NICHT aus dem Video
#    extrahiert. Mit Referenz-Frames lassen sich diese Werte präzise nachziehen.
# ----------------------------------------------------------------------------
def K(t, **kw):
    d = dict(BASE)
    d.update(kw)
    return (t, d)

PULL = [  # 24 Frames: Messer kommt geschlossen von unten, wird aufgeschnippt, federt nach
    K(0, ty=-6, rz=-10, ry=-70, rx=40, s=0.7, ha=-180, hb=180),
    K(6, ty=1, rz=10, ry=-80, rx=10, ha=-180, hb=180),
    K(11, ty=4.5, rz=40, ry=-95, rx=-25, ha=-150, hb=150),
    K(15, ty=4, rz=35, ry=-95, rx=-10, ha=-20, hb=20),
    K(17, ty=3.6, rz=30, ha=8, hb=-8),
    K(19, ha=-3, hb=3),
    K(23),
]

INSPECT = [  # 100 Frames: präsentieren, schließen, Rollover (Vollrotation der Griffe), Ein-Griff-Flip, zurück
    K(0),
    K(10, ry=-55, rz=12, tx=0.2, ty=3.6, tz=2.2, rx=-10),
    K(24, ry=-52, rz=12, tx=0.2, ty=3.6, tz=2.2, rx=-10),
    K(32, ry=-60, rz=20, rx=-15, ty=3.6, tz=2.0, ha=-180, hb=180),
    K(44, ry=-70, rz=15, rx=-200, ty=5, tz=1.6, ha=-180, hb=180),
    K(54, ry=-50, rz=12, rx=-360, ty=4, ha=-360, hb=360),
    K(62, ry=-50, rz=12, rx=-360, ty=3.4, ha=-360, hb=360),
    K(70, ry=-42, rz=5, rx=-360, ty=3.4, ha=-360, hb=540),
    K(80, ry=-60, rz=20, rx=-360, ty=3.6, ha=-360, hb=720),
    K(90, ry=-72, rz=24, rx=-360, ha=-360, hb=720),
    K(99, rx=-360, ha=-360, hb=720),
]

AURA = [  # 160 Frames: schneller, größer: Doppel-Rollover, Wurf nach oben, Fächer, Wechsel-Flips, Landung
    K(0),
    K(8, rz=38, rx=25, ty=2.4, ry=-95),
    K(18, rz=20, rx=-20, ry=-70, ty=4, ha=-180, hb=180),
    K(30, rz=15, rx=-360, ry=-55, ty=4.2, ha=-360, hb=360),
    K(40, rz=25, rx=-360, ry=-60, ty=3.5, ha=-360, hb=360),
    K(48, rz=25, rx=-720, ry=-75, ty=10, s=0.9, ha=-540, hb=540),
    K(58, rz=25, rx=-1080, ry=-75, ty=11.5, s=0.9, ha=-540, hb=540),
    K(68, rz=25, rx=-1440, ry=-90, ty=3.6, s=0.8, ha=-720, hb=720),
    K(74, rz=25, rx=-1440, ty=2.8, ha=-720, hb=720),
    K(84, rz=5, rx=-1440, ry=-45, ty=3.4, ha=-1080, hb=1080),
    K(96, rz=40, rx=-1500, ry=-105, ty=3.4, ha=-1440, hb=1440),
    K(108, rz=18, rx=-1440, ry=-60, ha=-1440, hb=1260),
    K(118, rz=18, rx=-1800, ry=-50, ha=-1440, hb=1260),
    K(128, rz=18, rx=-1800, ry=-60, ty=5, ha=-1620, hb=1260),
    K(138, rz=22, rx=-2160, ry=-70, ty=4.5, ha=-1800, hb=1440),
    K(146, rz=30, rx=-2160, ty=3.0, ha=-1800, hb=1440),
    K(152, rz=22, rx=-2160, ha=-1800, hb=1440),
    K(159, rx=-2160, ha=-1800, hb=1440),
]
SEQUENCES = [("pull", PULL, 24), ("inspect", INSPECT, 100), ("aura", AURA, 160)]

# ----------------------------------------------------------------------------
# 5. Monotone kubische Interpolation (Fritsch-Carlson), Ruhe an Anfang/Ende
# ----------------------------------------------------------------------------
def slopes(ts, vs):
    n = len(ts)
    d = [(vs[i + 1] - vs[i]) / (ts[i + 1] - ts[i]) for i in range(n - 1)]
    m = [0.0] * n
    for i in range(1, n - 1):
        m[i] = 0.0 if d[i - 1] * d[i] <= 0 else (d[i - 1] + d[i]) / 2
    for i in range(n - 1):
        if d[i] == 0:
            m[i] = m[i + 1] = 0.0
        else:
            a, b = m[i] / d[i], m[i + 1] / d[i]
            s = a * a + b * b
            if s > 9:
                tau = 3 / math.sqrt(s)
                m[i], m[i + 1] = tau * a * d[i], tau * b * d[i]
    return m

def evaluate(keys, ch, t):
    ts = [k[0] for k in keys]
    vs = [k[1][ch] for k in keys]
    if t <= ts[0]:
        return vs[0]
    if t >= ts[-1]:
        return vs[-1]
    m = slopes(ts, vs)
    for i in range(len(ts) - 1):
        if ts[i] <= t <= ts[i + 1]:
            h = ts[i + 1] - ts[i]
            u = (t - ts[i]) / h
            h00 = 2 * u**3 - 3 * u**2 + 1
            h10 = u**3 - 2 * u**2 + u
            h01 = -2 * u**3 + 3 * u**2
            h11 = u**3 - u**2
            return h00 * vs[i] + h10 * h * m[i] + h01 * vs[i + 1] + h11 * h * m[i + 1]

def wrap(a):
    return (a + 180) % 360 - 180

def frame_pose(keys, k):
    p = {ch: evaluate(keys, ch, k) for ch in BASE}
    for ch in ("rx", "ry", "rz", "ha", "hb"):
        p[ch] = wrap(p[ch])
    return p

# ----------------------------------------------------------------------------
# 6. Dateien schreiben
# ----------------------------------------------------------------------------
def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)

def main():
    base_dir = os.path.join(ASSETS, "models/item/base")
    if os.path.isdir(base_dir):
        for f in os.listdir(base_dir):
            os.remove(os.path.join(base_dir, f))
    write_json(os.path.join(base_dir, "static.json"), {
        "gui_light": "front", "ambientocclusion": False,
        "elements": elements(0, 0),
        "display": dict(STATIC_DISPLAY, firstperson_righthand=fp_display(BASE))})

    frame_no = 0
    layout = {}
    for name, keys, count in SEQUENCES:
        layout[name] = (frame_no + 1, count)
        for k in range(count):
            frame_no += 1
            p = frame_pose(keys, k)
            write_json(os.path.join(base_dir, f"f{frame_no:03d}.json"), {
                "gui_light": "front", "ambientocclusion": False,
                "elements": elements(p["ha"], p["hb"]),
                "display": {"firstperson_righthand": fp_display(p)}})
    total = frame_no

    sheet = Image.new("RGBA", (64 * len(VARIANTS), 64), (40, 40, 40, 255))
    for i, (vname, v) in enumerate(VARIANTS.items()):
        item = f"butterfly_knife_{vname}"
        sheet.alpha_composite(draw_texture(item, v), (64 * i, 0))
        vdir = os.path.join(ASSETS, "models/item", vname)
        tex = {"0": f"{NS}:item/{item}", "particle": f"{NS}:item/{item}"}
        write_json(os.path.join(vdir, "static.json"), {"parent": f"{NS}:item/base/static", "textures": tex})
        entries = []
        for n in range(1, total + 1):
            write_json(os.path.join(vdir, f"f{n:03d}.json"), {"parent": f"{NS}:item/base/f{n:03d}", "textures": tex})
            entries.append({"threshold": float(n), "model": {"type": "minecraft:model", "model": f"{NS}:item/{vname}/f{n:03d}"}})
        static = {"type": "minecraft:model", "model": f"{NS}:item/{vname}/static"}
        write_json(os.path.join(ASSETS, "items", f"{item}.json"), {"model": {
            "type": "minecraft:select", "property": "minecraft:display_context",
            "cases": [{"when": "firstperson_righthand", "model": {
                "type": "minecraft:range_dispatch", "property": "minecraft:custom_model_data",
                "index": 0, "fallback": static, "entries": entries}}],
            "fallback": static}})
    sheet.resize((sheet.width * 4, sheet.height * 4), Image.NEAREST).save(os.path.join(ROOT, "tools/texture_preview.png"))

    names_en = [("wood", "Wooden"), ("copper", "Copper"), ("iron", "Iron"), ("gold", "Golden"),
                ("diamond", "Diamond"), ("netherite", "Netherite"), ("stone", "Stone")]
    names_de = [("wood", "Holz"), ("copper", "Kupfer"), ("iron", "Eisen"), ("gold", "Gold"),
                ("diamond", "Diamant"), ("netherite", "Netherit"), ("stone", "Stein")]
    lang_en = {f"item.{NS}.butterfly_knife_{v}": f"{n} Butterfly Knife" for v, n in names_en}
    lang_en.update({f"key.{NS}.inspect": "Inspect Butterfly Knife",
                    f"key.{NS}.aura": "Aura Inspect Butterfly Knife",
                    f"key.category.{NS}.main": "Butterfly Knife"})
    lang_de = {f"item.{NS}.butterfly_knife_{v}": f"{n}-Butterflymesser" for v, n in names_de}
    lang_de.update({f"key.{NS}.inspect": "Butterflymesser inspizieren",
                    f"key.{NS}.aura": "Butterflymesser Aura-Inspect",
                    f"key.category.{NS}.main": "Butterflymesser"})
    write_json(os.path.join(ASSETS, "lang/en_us.json"), lang_en)
    write_json(os.path.join(ASSETS, "lang/de_de.json"), lang_de)

    with open(JAVA_OUT, "w", encoding="utf-8") as f:
        f.write("package dev.butterflyknife.client;\n\n"
                "// AUTOMATISCH ERZEUGT von tools/generate.py - nicht von Hand ändern.\n"
                "public final class AnimationFrames {\n")
        for name, (start, count) in layout.items():
            f.write(f"    public static final int {name.upper()}_START = {start};\n"
                    f"    public static final int {name.upper()}_COUNT = {count};\n")
        f.write(f"    public static final int TOTAL = {total};\n    private AnimationFrames() {{}}\n}}\n")
    print("Frames:", layout, "total", total)

if __name__ == "__main__":
    main()
