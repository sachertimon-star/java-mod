package dev.butterflyknife;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

import java.util.ArrayList;
import java.util.List;

public class ButterflyKnifeMod implements ModInitializer {
    public static final String MOD_ID = "butterflyknife";
    public static final List<Item> KNIVES = new ArrayList<>();

    @Override
    public void onInitialize() {
        for (KnifeVariant variant : KnifeVariant.values()) {
            Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, variant.itemName());
            ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
            Item item = new ButterflyKnifeItem(new Item.Properties().setId(key).stacksTo(1));
            Registry.register(BuiltInRegistries.ITEM, key, item);
            KNIVES.add(item);
        }
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT)
                .register(entries -> KNIVES.forEach(entries::accept));
    }
}
