package dev.butterflyknife;

import net.minecraft.world.item.Item;

/** Marker-Klasse: Der Client erkennt über instanceof, ob ein Butterflymesser in der Hand liegt. */
public class ButterflyKnifeItem extends Item {
    public ButterflyKnifeItem(Properties properties) {
        super(properties);
    }
}
