package dev.butterflyknife.client;

// AUTOMATISCH ERZEUGT von tools/generate.py - nicht von Hand ändern.
public final class AnimationFrames {
    public static final int PULL_START = 1;
    public static final int PULL_COUNT = 24;
    public static final int INSPECT_START = 25;
    public static final int INSPECT_COUNT = 100;
    public static final int AURA_START = 125;
    public static final int AURA_COUNT = 160;
    public static final int TOTAL = 284;
    private AnimationFrames() {}
}
