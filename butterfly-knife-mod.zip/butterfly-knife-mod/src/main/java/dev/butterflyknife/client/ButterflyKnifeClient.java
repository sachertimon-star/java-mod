package dev.butterflyknife.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.butterflyknife.ButterflyKnifeMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class ButterflyKnifeClient implements ClientModInitializer {
    public static KeyMapping INSPECT_KEY;
    public static KeyMapping AURA_KEY;

    @Override
    public void onInitializeClient() {
        // Standardtasten: F = Inspect, X = Aura-Inspect. Beide sind in den Steuerungs-Einstellungen umstellbar.
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(ButterflyKnifeMod.MOD_ID, "main"));
        INSPECT_KEY = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key." + ButterflyKnifeMod.MOD_ID + ".inspect", InputConstants.Type.KEYSYM, InputConstants.KEY_F, category));
        AURA_KEY = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key." + ButterflyKnifeMod.MOD_ID + ".aura", InputConstants.Type.KEYSYM, InputConstants.KEY_X, category));

        ClientTickEvents.END_CLIENT_TICK.register(KnifeAnimator::tick);
    }
}
