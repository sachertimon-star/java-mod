package dev.butterflyknife.client;

import dev.butterflyknife.ButterflyKnifeItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;

import java.util.List;

/**
 * Zustandsautomat für die Messer-Animationen (rein clientseitig).
 *
 * Jeder Tick wird genau ein vorgebackenes Modell-Frame gewählt. Dazu wird auf dem Item in der Hand die
 * Komponente CUSTOM_MODEL_DATA (float[0] = Frame-Nummer) gesetzt; die Item-Definition in
 * assets/butterflyknife/items/*.json wählt daraus das passende Modell.
 * Frame 0 = Ruhepose (Komponente entfernt).
 *
 * Zustände schließen sich gegenseitig aus: Während PULL/INSPECT/AURA läuft, werden neue Tasten ignoriert.
 */
public final class KnifeAnimator {
    private enum State { IDLE, PULL, INSPECT, AURA }

    private static State state = State.IDLE;
    private static int tick = 0;
    private static boolean wasKnife = false;
    private static int lastSlot = -1;

    private KnifeAnimator() {}

    public static void tick(Minecraft mc) {
        LocalPlayer player = mc.player;
        if (player == null) {
            reset();
            return;
        }
        ItemStack held = player.getMainHandItem();
        boolean isKnife = held.getItem() instanceof ButterflyKnifeItem;
        int slot = player.getInventory().getSelectedSlot();

        // Tasten immer abfragen, damit sich keine Klicks aufstauen
        boolean inspectPressed = false;
        boolean auraPressed = false;
        while (ButterflyKnifeClient.INSPECT_KEY.consumeClick()) inspectPressed = true;
        while (ButterflyKnifeClient.AURA_KEY.consumeClick()) auraPressed = true;

        if (!isKnife) {
            reset();
            wasKnife = false;
            lastSlot = slot;
            return;
        }

        // Messer neu in der Hand (Slot-Wechsel oder aufgenommen) -> Pull-Out
        if (!wasKnife || slot != lastSlot) {
            start(State.PULL);
        }
        wasKnife = true;
        lastSlot = slot;

        // Abbruch: Inventar/Menü offen oder Angriff -> zurück zur Ruhepose
        if (mc.screen != null || mc.options.keyAttack.isDown()) {
            if (state != State.IDLE) start(State.IDLE);
            apply(held, 0);
            return;
        }

        if (state == State.IDLE) {
            if (inspectPressed) start(State.INSPECT);
            else if (auraPressed) start(State.AURA);
        }

        int frame = 0;
        switch (state) {
            case PULL -> {
                frame = AnimationFrames.PULL_START + tick;
                if (++tick >= AnimationFrames.PULL_COUNT) start(State.IDLE);
            }
            case INSPECT -> {
                frame = AnimationFrames.INSPECT_START + tick;
                if (++tick >= AnimationFrames.INSPECT_COUNT) start(State.IDLE);
            }
            case AURA -> {
                frame = AnimationFrames.AURA_START + tick;
                if (++tick >= AnimationFrames.AURA_COUNT) start(State.IDLE);
            }
            case IDLE -> frame = 0;
        }
        apply(held, frame);
    }

    private static void start(State next) {
        state = next;
        tick = 0;
    }

    private static void reset() {
        state = State.IDLE;
        tick = 0;
    }

    private static void apply(ItemStack stack, int frame) {
        CustomModelData current = stack.get(DataComponents.CUSTOM_MODEL_DATA);
        if (frame == 0) {
            if (current != null) stack.remove(DataComponents.CUSTOM_MODEL_DATA);
            return;
        }
        stack.set(DataComponents.CUSTOM_MODEL_DATA,
                new CustomModelData(List.of((float) frame), List.of(), List.of(), List.of()));
    }
}
