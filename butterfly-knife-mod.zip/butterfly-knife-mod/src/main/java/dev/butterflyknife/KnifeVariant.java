package dev.butterflyknife;

/** Alle Messer-Varianten. Neue Variante = hier ergänzen + in tools/generate.py (VARIANTS) + Sprachdateien. */
public enum KnifeVariant {
    WOOD("wood"), COPPER("copper"), IRON("iron"), GOLD("gold"),
    DIAMOND("diamond"), NETHERITE("netherite"), STONE("stone");

    private final String key;

    KnifeVariant(String key) { this.key = key; }

    /** Registry-Pfad, z. B. "butterfly_knife_wood". */
    public String itemName() { return "butterfly_knife_" + key; }
}
