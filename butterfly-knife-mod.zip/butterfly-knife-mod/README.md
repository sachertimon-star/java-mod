# Butterfly Knife (Fabric, Minecraft 26.3)

Butterflymesser im Minecraft-Stil mit **7 Varianten** (Holz, Kupfer, Eisen, Gold, Diamant, Netherit, Stein), gleiche Animationen für alle.

## Steuerung
| Aktion | Taste (änderbar unter Optionen → Steuerung → „Butterflymesser") |
|---|---|
| Pull-Out | automatisch beim Auswählen des Messers |
| Inspect | `F` |
| Aura-Inspect | `X` |

Die Messer findest du im Kreativ-Tab „Kampf" oder mit `/give @s butterflyknife:butterfly_knife_diamond`.
Angriff (Linksklick) oder ein offenes Menü brechen die Animation ab. Während eine Animation läuft, werden weitere Tasten ignoriert, es überlagert sich nichts.

## Bauen
Voraussetzungen: **JDK 25**, Internetzugang.
```
gradle wrapper          # einmalig, falls kein gradlew vorhanden ist (oder die Wrapper-Dateien aus der Fabric-Vorlage kopieren)
./gradlew build         # JAR liegt danach in build/libs/
./gradlew runClient     # Spiel zum Testen starten
```
Zum Installieren: JAR in `.minecraft/mods`, dazu Fabric Loader ≥ 0.19.5 und Fabric API 0.161.0+26.3.

## Aufbau
```
tools/generate.py                  erzeugt Texturen, Modelle, Item-Definitionen, Lang-Dateien, AnimationFrames.java
src/main/java/dev/butterflyknife/  Item-Registrierung (KnifeVariant, ButterflyKnifeMod)
  client/KnifeAnimator.java        Zustandsautomat IDLE / PULL / INSPECT / AURA
  client/ButterflyKnifeClient.java Keybinds F und X
src/main/resources/assets/...      generierte Assets (werden mit ausgeliefert)
```

## Wie die Animation funktioniert
Pro Tick (20/s) gibt es ein vorgebackenes Modell: Pull-Out 24, Inspect 100, Aura-Inspect 160 Frames (284 je Variante).
Jedes Frame setzt die Griffwinkel (Schwenk um die Pivot-Nieten) und die Hand-Pose. Der Client wählt das Frame über `custom_model_data`, die Item-Definition (`items/*.json`) schlägt es nach. Es braucht keinen Renderer-Eingriff und kein GeckoLib.

**Bewegungen ändern:** Keyframes oben in `tools/generate.py` (`PULL`, `INSPECT`, `AURA`) bearbeiten, dann `python3 tools/generate.py` ausführen (`pip install pillow`).
**Neue Variante:** Eintrag in `VARIANTS` (generate.py), in `KnifeVariant.java`, Skript laufen lassen.

## Ehrlicher Stand
Dieser Code wurde ohne Netzwerk und ohne Minecraft geschrieben. **Er wurde weder kompiliert noch im Spiel getestet.**
- Die Namen in der 26.3-API sind aus dem Gedächtnis geschrieben und könnten leicht abweichen. Verdächtige Stellen: `Identifier` (früher `ResourceLocation`), `KeyMapping.Category`, `KeyMappingHelper` (früher `KeyBindingHelper`), `getSelectedSlot()`, die Loom-Plugin-ID/Version in `build.gradle`. Compilerfehler schick mir bitte, dann behebe ich sie.
- Die Modelle nutzen beliebige Rotationswinkel für die Griffe (0 bis ±180°). Falls das Spiel Winkel außerhalb von ±45° im Log ablehnt, sag Bescheid, dann stelle ich die Rotation um.
- **Die Bewegungen sind meine Annäherung an ein CS-Balisong, nicht aus dem Video extrahiert**, weil ich das Video nicht sehen kann. Mit Referenz-Frames lassen sie sich genau nachziehen.
- 20 Frames pro Sekunde (Tick-Takt), kein 60-fps-Rendering. Das ist die Grenze dieses Ansatzes. Für flüssigeres Rendering wäre ein eigener Renderer (z. B. GeckoLib) nötig.
- Nur die rechte Hand (Standard) wird animiert, in der linken Haupthand steht das Messer in Ruhepose.
- Messer haben noch keinen Schaden, kein Crafting-Rezept und keine Haltbarkeit.

## Modrinth-Beschreibung (Entwurf)
**Butterfly Knife** fügt Balisong-Messer in sieben Materialien hinzu: Holz, Kupfer, Eisen, Gold, Diamant, Netherit und Stein. Pixel-Optik im Minecraft-Stil, Pull-Out-Animation beim Ziehen, Inspect (`F`) und Aura-Inspect (`X`) mit Griff-Flips. Tasten frei belegbar. Fabric, Minecraft 26.3, benötigt Fabric API.
